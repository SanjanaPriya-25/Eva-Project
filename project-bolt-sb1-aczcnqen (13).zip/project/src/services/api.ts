import axios from 'axios';
import { createClient } from '@supabase/supabase-js';
import { v4 as uuidv4 } from 'uuid';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

export const createChat = async (title: string) => {
  const chatId = uuidv4();
  const { data, error } = await supabase
    .from('chats')
    .insert([{ 
      id: chatId,
      title,
      user_id: (await supabase.auth.getUser()).data.user?.id
    }])
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const getChats = async () => {
  const { data, error } = await supabase
    .from('chats')
    .select('*, messages(*)')
    .order('updated_at', { ascending: false });

  if (error) throw error;
  return data;
};

export const sendMessage = async (content: string, chatId: string) => {
  if (!chatId) {
    const newChat = await createChat(content.slice(0, 50));
    chatId = newChat.id;
  }

  // First save the user message
  const { data: userMessage, error: userError } = await supabase
    .from('messages')
    .insert([{
      id: uuidv4(),
      chat_id: chatId,
      content,
      role: 'user'
    }])
    .select()
    .single();

  if (userError) throw userError;

  try {
    const response = await fetch('https://priya-chatgptclone.web.val.run', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify({
        messages: [
          {
            role: 'system',
            content: `You are Eva, an advanced AI assistant created by Sanjana Priya from India. You provide detailed, well-structured responses with clear formatting and markdown.`
          },
          {
            role: 'user',
            content
          }
        ],
        model: 'gpt-4o-mini',
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const botResponse = data.message || "I apologize, but I'm having trouble processing your request at the moment.";

    // Save the bot's response
    const { data: botMessage, error: botError } = await supabase
      .from('messages')
      .insert([{
        id: uuidv4(),
        chat_id: chatId,
        content: botResponse,
        role: 'assistant'
      }])
      .select()
      .single();

    if (botError) throw botError;
    return { message: botMessage, chatId };

  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};

export const uploadFile = async (file: File) => {
  const fileId = uuidv4();
  const fileExt = file.name.split('.').pop();
  const filePath = `${fileId}.${fileExt}`;

  const { data, error } = await supabase.storage
    .from('chat-files')
    .upload(filePath, file);

  if (error) throw error;

  const { data: { publicUrl } } = supabase.storage
    .from('chat-files')
    .getPublicUrl(data.path);

  return { url: publicUrl, type: file.type, name: file.name };
};

export const getChatHistory = async (chatId: string) => {
  const { data, error } = await supabase
    .from('messages')
    .select('*')
    .eq('chat_id', chatId)
    .order('created_at', { ascending: true });

  if (error) throw error;
  return data;
};

export const generateChatTitle = (firstMessage: string) => {
  return firstMessage
    .slice(0, 40)
    .replace(/[^\w\s]/gi, '')
    .trim() + (firstMessage.length > 40 ? '...' : '');
};