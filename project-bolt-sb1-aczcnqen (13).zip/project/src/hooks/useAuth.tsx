import { createContext, useContext, useState, useEffect } from "react";
import { User, Session } from "@supabase/supabase-js";
import { supabase } from "../supabaseClient";

interface AuthContextType {
  user: User | null;
  session: Session | null;
  isAuthenticating: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithGithub: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (profile: { name?: string; email?: string; password?: string }) => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  session: null,
  isAuthenticating: true,
  signInWithGoogle: async () => {},
  signInWithGithub: async () => {},
  logout: async () => {},
  updateProfile: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session }, error }) => {
      if (error) {
        console.error("Error fetching session:", error.message);
      }
      setSession(session);
      setUser(session?.user ?? null);
      setIsAuthenticating(false);
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      setIsAuthenticating(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signInWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${window.location.origin}/home`,
      },
    });

    if (error) {
      console.error("Google Sign-in Error:", error.message);
      throw error;
    }
  };

  const signInWithGithub = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "github",
      options: {
        redirectTo: `${window.location.origin}/home`,
      },
    });

    if (error) {
      console.error("GitHub Sign-in Error:", error.message);
      throw error;
    }
  };

  const logout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error("Logout Error:", error.message);
      throw error;
    }
  };

  const updateProfile = async (profile: { name?: string; email?: string; password?: string }) => {
    if (!user) throw new Error("No user logged in");

    const updates: any = {};
    if (profile.email) updates.email = profile.email;
    if (profile.password) updates.password = profile.password;

    const { error } = await supabase.auth.updateUser(updates);
    if (error) throw error;

    if (profile.name) {
      const { error: profileError } = await supabase
        .from("profiles")
        .upsert({ id: user.id, name: profile.name }, { onConflict: "id" });
      if (profileError) throw profileError;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        isAuthenticating,
        signInWithGoogle,
        signInWithGithub,
        logout,
        updateProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}