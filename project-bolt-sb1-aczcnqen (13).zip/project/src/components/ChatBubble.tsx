import React, { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Copy, Check } from 'lucide-react';
import { cn } from '../utils/cn';

interface ChatBubbleProps {
  message: string;
  role: 'user' | 'assistant';
  isTyping?: boolean;
  userName?: string;
}

export function ChatBubble({ message = '', role, isTyping, userName = 'You' }: ChatBubbleProps) {
  const [displayedMessage, setDisplayedMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (role === 'assistant' && !isTyping) {
      setDisplayedMessage('');
      setIsStreaming(true);
      let index = 0;
      const interval = setInterval(() => {
        if (index < message.length) {
          setDisplayedMessage(prev => prev + message[index]);
          index++;
        } else {
          setIsStreaming(false);
          clearInterval(interval);
        }
      }, 20);

      return () => clearInterval(interval);
    } else {
      setDisplayedMessage(message);
      setIsStreaming(false);
    }
  }, [message, role, isTyping]);

  const handleCopy = () => {
    navigator.clipboard.writeText(message).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy: ', err);
    });
  };

  return (
    <div className={cn("flex w-full", role === "user" ? "justify-end" : "justify-start")}>
      <div className="flex max-w-2xl p-4 rounded-xl relative bg-gray-100 dark:bg-[#444654] text-black dark:text-white shadow-md">
        {/* Avatar */}
        {role === 'assistant' && (
          <div className="absolute left-[-40px] top-2">
            <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-white font-bold">
              G
            </div>
          </div>
        )}
        
        {/* Chat Content */}
        <div className="flex-1">
          <ReactMarkdown 
            remarkPlugins={[remarkGfm]} 
            className="prose dark:prose-invert max-w-none"
          >
            {displayedMessage}
          </ReactMarkdown>
          {isStreaming && <span className="ml-1 animate-pulse">|</span>}
        </div>

        {/* Copy Button (only for AI messages) */}
        {role === "assistant" && !isTyping && !isStreaming && (
          <button 
            onClick={handleCopy} 
            className="absolute right-2 top-2 p-1 opacity-0 group-hover:opacity-100 transition-opacity text-gray-500 dark:text-gray-400"
            aria-label="Copy message"
          >
            {copied ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </button>
        )}
      </div>
    </div>
  );
}