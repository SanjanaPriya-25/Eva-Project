import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Menu, MenuItem, MenuButton } from "./ui/menu";
import { MoreVertical, Plus } from "lucide-react";

interface SidebarProps {
  onSelectChat: (chat: Chat) => void;
  isOpen?: boolean;
  onClose?: () => void;
  onProfileClick?: () => void;
  onLogout?: () => void;
}

interface Chat {
  id: number;
  name: string;
  messages: any[];
}

export function Sidebar({ onSelectChat, isOpen = true, onClose, onProfileClick, onLogout }: SidebarProps) {
  const [chats, setChats] = useState<Chat[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);

  useEffect(() => {
    const savedChats = JSON.parse(localStorage.getItem("chats") || "[]");
    setChats(savedChats);
  }, []);

  useEffect(() => {
    localStorage.setItem("chats", JSON.stringify(chats));
  }, [chats]);

  const generateChatName = (messages: any[]) => {
    if (messages.length > 0) {
      return messages[0].content.slice(0, 20) + "..."; // Extract first 20 characters
    }
    return "New Chat";
  };

  const handleNewChat = () => {
    const newChat = { id: Date.now(), name: "New Chat", messages: [] };
    setChats([newChat, ...chats]);
    setSelectedChat(newChat);
    onSelectChat(newChat);
  };

  const handleRenameChat = (id: number) => {
    const newName = prompt("Enter new chat name:");
    if (newName) {
      setChats(chats.map(chat => chat.id === id ? { ...chat, name: newName } : chat));
    }
  };

  const handleDeleteChat = (id: number) => {
    setChats(chats.filter(chat => chat.id !== id));
  };

  if (!isOpen) return null;

  return (
    <div className="w-64 bg-gray-900 text-white p-3 flex flex-col h-screen">
      {/* New Chat Button (Styled like ChatGPT) */}
      <Button 
        onClick={handleNewChat} 
        className="w-full flex items-center justify-center gap-2 text-white bg-gray-700 hover:bg-gray-600 rounded-md py-2 mb-4"
      >
        <Plus size={16} /> New Chat
      </Button>
      
      {/* Chat List */}
      <div className="flex-1 overflow-y-auto space-y-1">
        {chats.map(chat => (
          <div 
            key={chat.id} 
            className={`flex items-center justify-between px-3 py-2 rounded-lg cursor-pointer transition-colors ${
              selectedChat?.id === chat.id ? "bg-gray-700 text-white" : "hover:bg-gray-800"
            }`}
            onClick={() => {
              setSelectedChat(chat);
              onSelectChat(chat);
            }}
          >
            <span className="truncate">{chat.name}</span>
            {/* Show menu only on hover */}
            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
              <Menu>
                <MenuButton>
                  <MoreVertical size={16} />
                </MenuButton>
                <MenuItem onClick={() => handleRenameChat(chat.id)}>Rename</MenuItem>
                <MenuItem onClick={() => handleDeleteChat(chat.id)}>Delete</MenuItem>
              </Menu>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Profile & Logout Section */}
      <div className="mt-auto pt-4 border-t border-gray-700">
        {onProfileClick && (
          <Button
            variant="ghost"
            className="w-full mb-2 text-gray-300 hover:bg-gray-800"
            onClick={onProfileClick}
          >
            Profile Settings
          </Button>
        )}
        {onLogout && (
          <Button
            variant="ghost"
            className="w-full text-red-400 hover:text-red-300"
            onClick={onLogout}
          >
            Sign Out
          </Button>
        )}
      </div>
    </div>
  );
}
