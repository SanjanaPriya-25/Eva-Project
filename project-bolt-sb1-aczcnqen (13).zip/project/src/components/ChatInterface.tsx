import React, { useState, useRef, useEffect, useCallback } from "react";
import { Send, Menu, X, Paperclip } from "lucide-react";
import { useDropzone } from "react-dropzone";
import { ChatBubble } from "./ChatBubble";
import { Sidebar } from "./Sidebar";
import { sendMessage, uploadFile } from "../services/api";
import { useAuth } from "../hooks/useAuth";
import { useNavigate } from "react-router-dom";

interface Message {
  id?: number;
  content: string;
  role: "user" | "assistant";
  file?: {
    url: string;
    type: string;
    name: string;
  };
}

interface Chat {
  id: number;
  name: string;
  messages: Message[];
}

const ChatInterface: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([
    {
      content: "Hello! I'm Eva, your AI assistant. How can I help you today?",
      role: "assistant",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentChat, setCurrentChat] = useState<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Handle file drop (Upload)
  const handleFileDrop = useCallback(async (acceptedFiles: File[]) => {
    try {
      for (const file of acceptedFiles) {
        const result = await uploadFile(file);
        setMessages((prev) => [
          ...prev,
          {
            content: `Shared ${file.type.startsWith("image/") ? "an image" : "a file"}: ${file.name}`,
            role: "user",
            file: { type: file.type.startsWith("image/") ? "image" : "file", url: result.url, name: file.name },
          },
        ]);
      }
    } catch {
      setMessages((prev) => [...prev, { content: "Failed to upload file.", role: "assistant" }]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: handleFileDrop,
    noClick: true,
    noKeyboard: true,
  });

  // Scroll to the latest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Auto-focus input field
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  // Handle sending messages
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { content: userMessage, role: "user" }]);
    setIsTyping(true);

    try {
      const response = await sendMessage(userMessage, currentChat?.id.toString() || "");
      setMessages((prev) => [...prev, { content: response.content, role: "assistant" }]);
    } catch {
      setMessages((prev) => [...prev, { content: "Error sending message.", role: "assistant" }]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSelectChat = (chat: Chat) => {
    if (chat.id !== currentChat?.id) {
      setCurrentChat(chat);
      setMessages(chat.messages);
    }
  };

  const handleProfileClick = () => {
    navigate("/profile");
  };

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <Sidebar
        onSelectChat={handleSelectChat}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        onProfileClick={handleProfileClick}
        onLogout={logout}
      />

      {/* Chat Container */}
      <div className="flex-1 flex flex-col relative bg-white dark:bg-[#343541]" {...getRootProps()}>
        <input {...getInputProps()} />
        
        {/* Chat Header */}
        <div className="p-4 flex items-center justify-between border-b border-gray-200 dark:border-gray-700">
          <button onClick={() => setIsSidebarOpen(true)} className="text-gray-600 dark:text-gray-300">
            <Menu className="w-6 h-6" />
          </button>
          <h2 className="text-lg font-medium text-gray-900 dark:text-white">Eva Chat</h2>
          <button onClick={handleProfileClick} className="text-gray-600 dark:text-gray-300">
            {user?.name || "Guest"}
          </button>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {messages.map((msg, idx) => (
            <ChatBubble key={idx} message={msg.content} role={msg.role} userName={user?.name || "You"} file={msg.file} />
          ))}
          {isTyping && <ChatBubble message="..." role="assistant" isTyping />}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Box */}
        <form onSubmit={handleSubmit} className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-2 bg-gray-100 dark:bg-[#40414F] p-3 rounded-xl">
            {/* File Upload Button */}
            <button type="button" className="text-gray-600 dark:text-gray-300">
              <Paperclip className="w-5 h-5" />
            </button>

            {/* Input Field */}
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Message Eva..."
              className="flex-1 bg-transparent focus:outline-none text-gray-900 dark:text-white"
            />

            {/* Send Button */}
            <button
              type="submit"
              disabled={!input.trim() || isTyping}
              className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-500 disabled:opacity-50"
            >
              <Send className="w-6 h-6" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
