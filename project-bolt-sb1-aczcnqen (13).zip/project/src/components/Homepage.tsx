import React from "react";
import { MessageSquare, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleStartChat = () => {
    navigate("/chat");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 bg-gray-50 dark:bg-gray-900 transition-opacity animate-fade-in">
      {/* Icon Container */}
      <div className="w-20 h-20 bg-gray-200 dark:bg-gray-800 rounded-xl flex items-center justify-center mb-6">
        <MessageSquare className="w-10 h-10 text-gray-900 dark:text-white" />
      </div>

      {/* Title */}
      <h1 className="text-4xl font-bold text-gray-900 dark:text-white text-center">
        Welcome to Eva AI
      </h1>

      {/* Subtitle */}
      <p className="text-lg text-gray-600 dark:text-gray-400 text-center max-w-lg mt-2">
        An intelligent chatbot designed to assist and engage in meaningful conversations.
      </p>

      {/* Call-to-Action Button */}
      <button
        onClick={handleStartChat}
        className="mt-6 flex items-center gap-3 px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-full text-lg font-medium hover:opacity-80 transition-opacity"
      >
        Start Chatting
        <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );
};

export default HomePage;
