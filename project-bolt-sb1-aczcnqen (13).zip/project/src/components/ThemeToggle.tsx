import React from "react";
import { Sun, Moon } from "lucide-react";
import { useTheme } from "../hooks/useTheme";

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="fixed top-4 right-4 p-3 rounded-full bg-gray-200 dark:bg-gray-800 text-gray-600 dark:text-gray-300 
        hover:bg-gray-300 dark:hover:bg-gray-700 transition-all duration-300 z-50 shadow-md"
      aria-label="Toggle Theme"
    >
      <span className="transition-opacity duration-300 ease-in-out">
        {theme === "dark" ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
      </span>
    </button>
  );
}
