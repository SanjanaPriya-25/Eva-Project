import React from 'react';

interface MenuProps {
  children: React.ReactNode;
}

interface MenuItemProps {
  children: React.ReactNode;
  onClick?: () => void;
}

interface MenuButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
}

export function Menu({ children }: MenuProps) {
  return (
    <div className="relative inline-block text-left">
      {children}
    </div>
  );
}

export function MenuItem({ children, onClick }: MenuItemProps) {
  return (
    <button
      className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-700"
      onClick={onClick}
    >
      {children}
    </button>
  );
}

export function MenuButton({ children, onClick }: MenuButtonProps) {
  return (
    <button
      className="flex items-center justify-center w-8 h-8 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
      onClick={onClick}
    >
      {children}
    </button>
  );
}