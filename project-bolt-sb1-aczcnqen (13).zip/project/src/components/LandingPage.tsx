import React from "react";
import { useNavigate } from "react-router-dom";
import { Bot, ArrowRight } from "lucide-react";

const LandingPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 bg-gray-50 dark:bg-gray-900 transition-opacity animate-fade-in">
      {/* Logo/Branding */}
      <div className="w-20 h-20 bg-gray-200 dark:bg-gray-800 rounded-xl flex items-center justify-center mb-6">
        <Bot className="w-10 h-10 text-gray-900 dark:text-white" />
      </div>

      {/* Heading */}
      <h1 className="text-5xl font-bold text-gray-900 dark:text-white text-center">
        Meet Eva, Your AI Assistant
      </h1>

      {/* Subheading */}
      <p className="text-xl text-gray-600 dark:text-gray-400 text-center max-w-2xl mt-2">
        Intelligent conversations, seamless assistance, and a world of knowledge at your fingertips.
      </p>

      {/* Call-to-Action Button */}
      <button
        onClick={() => navigate("/chat")}
        className="mt-6 flex items-center gap-3 px-6 py-3 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-full text-lg font-medium hover:opacity-80 transition-opacity"
      >
        Get Started
        <ArrowRight className="w-5 h-5" />
      </button>

      {/* Feature Highlights */}
      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full px-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Intelligent Conversations
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Experience natural, context-aware conversations powered by advanced AI.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Personalized Assistance
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Eva adapts to your needs, providing smarter and more efficient responses.
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
            Secure & Private
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Your conversations are encrypted and private, ensuring full security.
          </p>
        </div>
      </div>

      {/* Footer Section */}
      <div className="mt-12 text-center text-gray-500 dark:text-gray-400 text-sm">
        © 2025 Eva AI. All rights reserved.
      </div>
    </div>
  );
};

export default LandingPage;
