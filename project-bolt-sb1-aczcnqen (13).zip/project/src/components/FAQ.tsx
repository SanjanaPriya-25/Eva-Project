import React from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'What is GPT-2 and how does it work?',
    answer: 'GPT-2 is an advanced language model developed by OpenAI. It uses deep learning to understand and generate human-like text based on the input it receives.',
  },
  {
    question: 'Is my conversation data private and secure?',
    answer: 'Yes, we take privacy seriously. All conversations are encrypted and we never store personal information without explicit consent.',
  },
  {
    question: 'Can I use this chatbot for business purposes?',
    answer: 'Absolutely! Our AI chatbot can be customized for various business needs, from customer service to data analysis.',
  },
  {
    question: 'What makes this chatbot different from others?',
    answer: 'Our chatbot combines state-of-the-art GPT-2 technology with a user-friendly interface, providing more natural and context-aware conversations.',
  },
];

export function FAQ() {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-4">
      {faqs.map((faq, idx) => (
        <details
          key={idx}
          className="group bg-gray-50 dark:bg-gray-700 rounded-2xl shadow-sm"
        >
          <summary className="flex items-center justify-between px-6 py-4 cursor-pointer list-none">
            <h3 className="font-medium text-gray-900 dark:text-white">{faq.question}</h3>
            <ChevronDown className="w-5 h-5 text-gray-500 dark:text-gray-400 transition-transform group-open:rotate-180" />
          </summary>
          <div className="px-6 pb-4">
            <p className="text-gray-600 dark:text-gray-300">{faq.answer}</p>
          </div>
        </details>
      ))}
    </div>
  );
}