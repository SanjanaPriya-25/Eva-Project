import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import * as path from "path";
import { fileURLToPath } from "url";

// Fix for __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ✅ Correct & Clean Vite Config
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  server: {
    port: 5174, // Changed to avoid conflict
    strictPort: false, // Allow fallback to next available port
  },
  define: {
    "process.env": {}, // Fixes env variable issues
    "__WS_TOKEN__": JSON.stringify("development"), // Fix WebSocket token issue
  },
});