/*
  # Update messages table schema

  1. Changes
    - Add `role` column to messages table to replace `is_bot`
    - Drop `is_bot` column if it exists
    - Add check constraint to ensure valid roles

  2. Data Migration
    - Convert existing `is_bot` values to appropriate roles
*/

DO $$ 
BEGIN
  -- Add role column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'messages' AND column_name = 'role'
  ) THEN
    ALTER TABLE messages ADD COLUMN role text NOT NULL DEFAULT 'user';
    ALTER TABLE messages ADD CONSTRAINT messages_role_check 
      CHECK (role IN ('user', 'assistant'));
  END IF;

  -- Drop is_bot column if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'messages' AND column_name = 'is_bot'
  ) THEN
    ALTER TABLE messages DROP COLUMN is_bot;
  END IF;
END $$;