/*
  # Fix UUID issues and add constraints

  1. Changes
    - Ensure all ID columns use UUID type with proper defaults
    - Add NOT NULL constraints where appropriate
    - Add indexes for better performance
    
  2. Security
    - Maintain existing RLS policies
    - Ensure proper user access control
*/

-- Update chats table
DO $$ 
BEGIN
  -- Set default for id if not already set
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'chats' 
    AND column_name = 'id' 
    AND column_default = 'gen_random_uuid()'
  ) THEN
    ALTER TABLE chats ALTER COLUMN id SET DEFAULT gen_random_uuid();
  END IF;

  -- Set user_id to NOT NULL if not already set
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'chats' 
    AND column_name = 'user_id' 
    AND is_nullable = 'YES'
  ) THEN
    ALTER TABLE chats ALTER COLUMN user_id SET NOT NULL;
  END IF;
END $$;

-- Update messages table
DO $$ 
BEGIN
  -- Set default for id if not already set
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'messages' 
    AND column_name = 'id' 
    AND column_default = 'gen_random_uuid()'
  ) THEN
    ALTER TABLE messages ALTER COLUMN id SET DEFAULT gen_random_uuid();
  END IF;

  -- Set chat_id to NOT NULL if not already set
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'messages' 
    AND column_name = 'chat_id' 
    AND is_nullable = 'YES'
  ) THEN
    ALTER TABLE messages ALTER COLUMN chat_id SET NOT NULL;
  END IF;
END $$;

-- Add indexes if they don't exist
CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id);
CREATE INDEX IF NOT EXISTS idx_chats_user_id ON chats(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);

-- Add role constraint if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE table_name = 'messages' 
    AND constraint_name = 'check_valid_role'
  ) THEN
    ALTER TABLE messages
    ADD CONSTRAINT check_valid_role
    CHECK (role IN ('user', 'assistant'));
  END IF;
END $$;