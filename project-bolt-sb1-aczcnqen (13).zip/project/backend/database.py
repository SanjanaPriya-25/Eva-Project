from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv

load_dotenv()

# ✅ Use Supabase PostgreSQL if available, else fallback to SQLite for local testing
DATABASE_URL = os.getenv("SUPABASE_DATABASE_URL", "sqlite:///./chat.db")

# ✅ Create Engine (optimized for Supabase & SQLite)
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
    pool_size=10,  # Ensures stable connections
    max_overflow=20,  # Handles traffic spikes
)

# ✅ Create Session Local
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ✅ Base Model for ORM
Base = declarative_base()
