import { pipeline } from "@xenova/transformers";

let chatbot = null;

// Load model only once (caching)
async function loadModel() {
  if (!chatbot) {
    console.log("Loading AI model...");
    try {
      chatbot = await pipeline("text-generation", "Xenova/gpt2");
      console.log("AI model loaded!");
    } catch (error) {
      console.error("Error loading model:", error);
      process.exit(1); // Exit the process if loading fails
    }
  }
}

// Generate AI response
export async function getAIResponse(userInput) {
  try {
    console.log("User input:", userInput); // Log the input
    await loadModel(); // Ensure model is loaded
    const response = await chatbot(userInput, { max_length: 100 });
    console.log("AI Response:", response);  // Log the response
    return response[0].generated_text;
  } catch (error) {
    console.error("Error generating response:", error);
    return "Sorry, something went wrong.";
  }
}

// If script is run from CLI
if (process.argv[2]) {
  getAIResponse(process.argv[2]).then(console.log).catch(console.error);
} else {
  console.log("No user input provided.");
}
