import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    PROJECT_NAME = "Eva AI Chat"
    PROJECT_VERSION = "1.0.0"
    
    # Database (Supabase for production, SQLite for local testing)
    DATABASE_URL = os.getenv("SUPABASE_DATABASE_URL", "sqlite:///./chat.db")
    
    # Authentication settings
    SECRET_KEY = os.getenv("SECRET_KEY", "your-very-secure-secret-key")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = 60  # Set to 1 hour like ChatGPT

    # AI Model (Updated to GPT-2, which you used)
    MODEL_NAME = "gpt2"  # Works better than DialoGPT for chatbot-like responses

    # Generation parameters (fine-tuned for better AI responses)
    MAX_LENGTH = 2048  # GPT-2 supports up to 2048 tokens
    TEMPERATURE = 0.7  # Balanced creativity & control
    TOP_P = 0.9
    DO_SAMPLE = True  # Enables sampling for better variation
    NO_REPEAT_NGRAM_SIZE = 3  # Prevents repetitive responses

settings = Settings()
