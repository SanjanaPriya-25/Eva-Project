import subprocess
import json
from fastapi import FastAPI, HTTPException, Depends, WebSocket, WebSocketDisconnect, UploadFile, File, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List
import models
import schemas
import crud
from database import SessionLocal, engine
from auth import create_access_token, get_current_user
import os
from dotenv import load_dotenv
import aiofiles
from pathlib import Path

load_dotenv()

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Eva AI Chat API")

# Create uploads directory if it doesn't exist
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# CORS configuration
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

@app.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    current_user: schemas.User = Depends(get_current_user)
):
    try:
        user_upload_dir = UPLOAD_DIR / str(current_user.id)
        user_upload_dir.mkdir(exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_filename = f"{timestamp}_{file.filename}"
        file_path = user_upload_dir / safe_filename

        async with aiofiles.open(file_path, 'wb') as out_file:
            content = await file.read()
            await out_file.write(content)

        file_url = f"/uploads/{current_user.id}/{safe_filename}"

        return {"url": file_url, "filename": file.filename, "content_type": file.content_type}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/token")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)
):
    user = crud.authenticate_user(db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, user=user)

@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int, db: Session = Depends(get_db)):
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_json()
            message = data.get("message", "")

            # Save user message
            user_message = crud.create_message(
                db=db,
                message=schemas.MessageCreate(content=message),
                user_id=user_id,
                is_bot=False
            )

            # Get AI response **from the subprocess**
            ai_response = await get_ai_response(message)

            # Save AI response in the database
            ai_message = crud.create_message(
                db=db,
                message=schemas.MessageCreate(content=ai_response),
                user_id=user_id,
                is_bot=True
            )

            await websocket.send_json({"response": ai_response})

    except WebSocketDisconnect:
        print(f"Client #{user_id} disconnected")

@app.get("/chat/history/", response_model=List[schemas.Message])
def get_chat_history(
    current_user: schemas.User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    messages = crud.get_user_messages(db, user_id=current_user.id)
    return messages

# AI response function using subprocess to call the JavaScript AI model
async def get_ai_response(user_input: str) -> str:
    # Run the JS script and capture the output
    process = subprocess.run(
        ["node", "ai_model.js", user_input], capture_output=True, text=True
    )
    
    response = process.stdout.strip()  # Get the chatbot output
    return response  # Return AI-generated response

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
